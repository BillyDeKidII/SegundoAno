
/**
 * Write a description of class Musica here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Musica{
	private String artist;
	private String music;
	public void setArtist(String artist){
		this.artist = artist;
	}
	public void setMusic(String music){
		this.music = music;
	}
	public String getArtist(){
		return this.artist;
	}
	public String getMusic(){
		return this.music;
	}

}
