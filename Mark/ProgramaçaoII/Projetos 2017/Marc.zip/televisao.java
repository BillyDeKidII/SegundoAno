
/**
 * Write a description of class televisao here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class televisao{
	private int canal;
	private int volume;
	private boolean ligar;
	
	public void setCanal(int canal){
		this.canal = canal;
	}
	public void setVolume(int volume){
		this.volume = volume;
	}
	public void setLigar(boolean status){
		this.ligar = status;
	}
	public int getCanal(){
		return this.canal;
	}
	public int getVolume(){
		return this.volume ;
	}
	public boolean getLigar(){
		return this.ligar;
	}

}
