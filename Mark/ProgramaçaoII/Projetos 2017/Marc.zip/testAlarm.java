public class testAlarm{
		public static void main(String[] args){
			
			Alarm a = new Alarm();
			a.setTime("11:30");
			a.setSound("Macarena");
			a.setAlarm("11:30");
			System.out.println(a.getTime());
			System.out.println(a.getSound());
			System.out.println(a.getAlarm());
			System.out.println(a.snooze());

		}
	}