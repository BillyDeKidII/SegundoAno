public class testBotao{
		public static void main(String[] args) {
			Botao button = new Botao();
			button.setAtivar(true);
			button.setColor("Red");
			System.out.println(button.getAtivar());
			System.out.println(button.getColor());
		}
	}