public class testMusic{
		 public static void main(String[] args) {
			Musica sing = new Musica();
			sing.setArtist("anita");
			sing.setMusic("bang bang");
			System.out.println(sing.getMusic());
			System.out.println(sing.getArtist());
		}
	}