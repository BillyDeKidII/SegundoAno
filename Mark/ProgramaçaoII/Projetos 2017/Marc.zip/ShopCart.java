
/**
 * Write a description of class ShopCart here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class ShopCart{
	private String produto;
	private int 10 quantidade;

	public void setProduto(String produto){
		for(int i = 0; i < 11;i++){
			this.produto[i] = produto;
		}			
	}
	public void setQuantidade(String quantidade){
		for (int i = 0;i < 11 ;i++ ) {
			this.quantidade[i] = quantidade;
		}
	}
	public String[] getProdutos(){
		return this.produto;
	}
	public int[] getQuantidade(){
		return this.quantidade;
	}
	public String lista(){
		String lista;
		for (int i = 0;i < 11 ;i++ ) {
			lista = this.produto[i] +"" + this.quantidade[i] +",";
		}
	}

}
