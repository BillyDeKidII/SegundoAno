
/**
 * Write a description of class Musica here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Botao{
	private boolean ativar;
	private String color;
	public void setAtivar(boolean status){
		this.ativar = status;

	}
	public void setColor(String color){
		this.color = color;
	}
	public String getAtivar(){
		if(this.ativar == true){
			return "Ligado";
		} else {
			return "Desligado";
		}
	}
	public String getColor(){
		return this.color;
	}

}
