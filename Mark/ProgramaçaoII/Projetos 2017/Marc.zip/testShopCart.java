public class testShopCart{
		 public static void main(String[] args) {
			ShopCart carrinho = new ShopCart();
			carrinho.setProduto();
			carrinho.setQuantidade();
			String[] prod = carrinho.getProdutos();
			int[] quant = carrinho.getQuantidade();
			String list = carrinho.lista();
		}
	}