	public class testTelevisao{
		 public static void main(String[] args) {
			televisao tv =  new televisao();
			tv.setLigar(true);
			tv.setVolume(15);
			tv.setCanal(05);
			System.out.println(tv.getLigar());
			System.out.println(tv.getCanal());
			System.out.println(tv.getVolume());
		}
	}