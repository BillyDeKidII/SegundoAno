
/**
 * Write a description of class Alarm here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Alarm
{
	private String time;
	private String sound;
	private String alarm;
	public void setTime(String time){
		this.time = time;
	}
	public void setSound(String sound){
		this.sound = sound;
	}
	public void setAlarm(String time){
		this.alarm = time;
	}
	public String getTime(){
		return this.time;	
	}
	public String getSound(){
		return this.sound;
	}
	public String getAlarm(){
		return this.alarm;
	}
 	public String snooze(){
		if (this.time == this.alarm){
			return this.sound;
		}
		
	}
}
