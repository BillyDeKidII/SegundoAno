
/**
 * Write a description of class Node here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class Node
{
    private char caracter;
    private int count;
    private Node direita;
    private Node esquerda;
    public Node(){
        
    }
    
    public void setCaracter(char _caracter){
        this.caracter = _caracter;
    }
    
    public char getCaracter(){
        return this.caracter;
    }
    
    public void setCount(int _count){
        this.count = _count;
    }
    
    public void setNodeDireita(Node _node){
        this.direita = _node;
    }
    
    public void setNodeEsquerda(Node _node){
        this.esquerda = _node;
    }
    
    public int getCount(){
        return this.count;
    }
    
    public Node getNodeDireita(){
        return this.direita;
    }
    
    public Node getNodeEsquerda(){
        return this.esquerda;
    }    
}
