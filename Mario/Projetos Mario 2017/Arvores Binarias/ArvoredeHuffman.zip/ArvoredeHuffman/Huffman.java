import java.util.*;
/**
 * Write a description of class Huffman here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class Huffman
{
    public void Decode(String text){
        List<Node> arvore = new ArrayList();
        
        int i = 0;
        Node no = new Node();
        no.setCaracter(text.charAt(i));
        no.setCount(1);
        arvore.add(no);
        i++;
        
        while(i < text.length()){
            for(int j = 0; j < arvore.size(); j++){
                if(text.charAt(i) == arvore.get(j).getCaracter()){
                    Node aux = arvore.get(j);
                    aux.setCount(aux.getCount() + 1);
                    i++;
                }else{
                    Node aux = new Node();
                    aux.setCaracter(text.charAt(i));
                    aux.setCount(1);
                    arvore.add(aux);
                    i++;
                }
            }
        }
    }
}